import React from 'react';

const LeaveManagement = () => {
  return (
    <div>
      <h2>Leave Management</h2>
      <p>Manage employee leave requests and approvals.</p>
    </div>
  );
};

export default LeaveManagement;
