import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>View reports, manage users, and access administrative tools.</p>
    </div>
  );
};

export default AdminDashboard;
