import React from 'react';

const Offboarding = () => {
  return (
    <div>
      <h2>Employee Offboarding</h2>
      <p>Handle the offboarding process and ensure all tasks are completed.</p>
    </div>
  );
};

export default Offboarding;
