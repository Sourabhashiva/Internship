import React, { useState } from "react";
import "./App.css";

const App = () => {
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [userInput, setUserInput] = useState("");
  const [error, setError] = useState("");

  function generateCaptcha() {
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let captcha = "";
    for (let i = 0; i < 6; i++) {
      captcha += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return captcha;
  }

  const validateCaptcha = (e) => {
    e.preventDefault();

    if (userInput === captcha) {
      setError("");
      alert("CAPTCHA verification passed! Logging in...");
    } else {
      setError("Invalid CAPTCHA. Please try again.");
      setCaptcha(generateCaptcha());
      setUserInput("");
    }
  };

  return (
    <div className="login-container">
      <a href="landingpage.html">
        <img src="team.png" alt="HRMS Logo" />
      </a>
      <h2>Welcome Back</h2>
      <form onSubmit={validateCaptcha}>
        <div className="input-group">
          <input type="email" placeholder="Email" required />
        </div>
        <div className="input-group">
          <input type="password" placeholder="Password" required />
        </div>
        <div className="captcha-group">
          <div className="captcha-text">{captcha}</div>
          <input
            type="text"
            placeholder="Enter CAPTCHA"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            required
          />
        </div>
        {error && <div className="error-message">{error}</div>}
        <button type="submit" className="login-btn">
          Login
        </button>
      </form>
      <div className="forgot-password">
        <a href="#">Forgot Password?</a>
      </div>
      <div className="register-link">
        <p>
          Don't have an account? <a href="#">Register</a>
        </p>
      </div>
    </div>
  );
};

export default App;