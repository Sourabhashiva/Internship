document.querySelector(".dropdown .btn").addEventListener("click", function () {
    const dropdownContent = document.querySelector(".dropdown-content");
    dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
});
